The strcuture of the source code is as follows: 

The code found in src>hef6>cmas>main is the entire technical submission for this project
The classes in this directory are: 

BoldAgentData.java
BoldAgents.java
BoldAgentsTest.java 
FlockClass.java
FlockData.java
LeaderClass.java
LeaderData.java
ShyAgentData.java
ShyAgents.java
SimGUI.java 
Simulator.java 
SimulatorTest.java 
VectorData.java

The source code is located within the src folder; in order to run the application successfully
using an IDE it will be necessary to add jgoodies.jar (included in the submission) to the class
path if not already done so. 

POST-SUBMISSION NOTES, PLEASE READ:
Unit testing incomplete as of 04/05/2018 - current release of simulator remains bugged.
Knows issue with UI not functioning as part of the JAR, some aspects of simularion can be controlled 
but UI was incomplete as of 04/05/2018.
No Bold-Agents ("leaders") can be spawned within the JAR as it is purefuly for the purposes of demonstrating the Boids algorithm. 

PROJECT INFORMATION: 
Subject: Collective Learning in Multi-Agent Systems 
Title: Simulation of the distributed multi-agent model flocking and how this model is affected by the role of leadership. 