 /*
 * @(#) FlockData.java 1.0 2018/04/05
 *
 * Copyright (c) 2018 Henry Finlay.
 * All rights reserved.
 *
 */

/**
* This class is a data class for the parent class FlockClass
* This class implements getters and setters for FlockClass.java
* @author Henry Finlay
* @version 1.0 Released
* @see ShyAgents.java
* @see FlockClass.java
* @see Simulator.java
*/

package hef6.cmas.main;

import java.util.List;

/**
* This class is a data class for the parent FlockClass.java
* This class implements getters and setters for FlockClass.java
* @author Henry Finlay
* @version 1.0 Released
* @see FlockClass.java
* @see ShyAgents.java
* @see LeaderClass.java
* @see Simulator.java
*/

public class FlockData {
	private List<ShyAgent> shyBoids;
	private List<BoldAgent> boldBoids;

	public FlockData() {
	}

	public List<ShyAgent> getShyBoids() {
		return shyBoids;
	}

	public void setShyBoids(List<ShyAgent> shyBoids) {
		this.shyBoids = shyBoids;
	}

	public List<BoldAgent> getBoldBoids() {
		return boldBoids;
	}

	public void setBoldBoids(List<BoldAgent> boldBoids) {
		this.boldBoids = boldBoids;
	}
}