 /*
 * @(#) LeaderData.java 1.0 2018/04/05
 *
 * Copyright (c) 2018 Henry Finlay.
 * All rights reserved.
 *
 */




package hef6.cmas.main;

import java.util.List;

/**
* This class is a data class for the parent class LeaderClass.java
* This class implements getters and setters for LeaderClass.java
* @author Henry Finlay
* @version 1.0 Released
* @see BoldAgents.java
* @see LeaderClass.java
* @see Simulator.java
*/

public class LeaderData {
	private List<BoldAgent> boldBoids;

	public LeaderData() {
	}

	public List<BoldAgent> getBoldBoids() {
		return boldBoids;
	}

	public void setBoldBoids(List<BoldAgent> boldBoids) {
		this.boldBoids = boldBoids;
	}
}