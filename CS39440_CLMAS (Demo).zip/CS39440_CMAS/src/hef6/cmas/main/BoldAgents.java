 /*
 * @(#) BoldAgents.java 1.0 2018/04/05
 *
 * Copyright (c) 2018 Henry Finlay.
 * All rights reserved.
 *
 */

package hef6.cmas.main;

import static java.lang.Math.PI;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Path2D;
import java.util.List;
import java.util.Random;

/**
* This class implements Bold Agents 
* <p>
* This class implements the 3 principles of the Boids algorithm, Separation, Alignment and Cohesion 
* with these principles corresponding the following methods: 
* principle1(List<BoldAgent> boids)
* principle2(List<BoldAgent> boids)
* principle3(List<BoldAgent> boids)
* This class paints BoldAgents 
* This class implements attributes/behaviours of BoldAgents
* 
* @author Henry Finlay
* @version 1.0 Released
* @see BoldAgentsData.java
* @see LeaderClass.java
* @see Simulator.java
*/

public class BoldAgents {

	protected static final Random r = new Random();
	static final Vector shift = new Vector(0.02, 0);
	protected static final int boldAgentSize = 3;
	protected static final Path2D boldAgent = new Path2D.Double();
	protected BoldAgentData boldAgentData = new BoldAgentData(true);

	public BoldAgents() {
		super();
	}

	void refresh() {
	   	  boldAgentData.getVelocity().add(boldAgentData.getAcceleration());
	   	  boldAgentData.getVelocity().limit(boldAgentData.getMomentum());
	   	  boldAgentData.getLocation().add(boldAgentData.getVelocity());
	   	  boldAgentData.getAcceleration().mult(0);
	       
	   }

	void addPower(Vector force) {
	       boldAgentData.getAcceleration().add(force);
	   }

	Vector search(Vector target) {
	       Vector steerBoid = Vector.sub(target, boldAgentData.getLocation());
	       steerBoid.normalize();
	       steerBoid.mult(boldAgentData.getMomentum());
	       steerBoid.sub(boldAgentData.getVelocity());
	       steerBoid.limit(boldAgentData.getPower());
	       return steerBoid;
	   }

	void leader(Graphics2D g, List<BoldAgent> boids) {
	       vision(g, boids);
	
	       Vector separation = principle1(boids);
	       Vector alignment = principle2(boids);
	       Vector cohesion = principle3(boids);
	
	       separation.mult(2.5);
	       alignment.mult(1.5);
	       cohesion.mult(1.3);
	       
	       addPower(separation);
	       addPower(alignment);
	       addPower(cohesion);
	       addPower(shift);
	       
	       
	   }

	void vision(Graphics2D g, List<BoldAgent> boids) {
	       double visionDistance = 100;
	       double fieldOfView = PI * 0.85;
	
	       for (BoldAgent b : boids) {
	           b.boldAgentData.setIncluded(false);
	
	           if (b == this)
	               continue;
	
	           double distance = Vector.dist(boldAgentData.getLocation(), b.boldAgentData.getLocation());
	           if (distance <= 0 || distance > visionDistance)
	               continue;
	
	           Vector lineOfSight = Vector.sub(b.boldAgentData.getLocation(), boldAgentData.getLocation());
	
	           double angle = Vector.angleBetween(lineOfSight, boldAgentData.getVelocity());
	           if (angle < fieldOfView)
	               b.boldAgentData.setIncluded(true);
	       }
	   }

	Vector principle1(List<BoldAgent> boids) {
	   double desiredSep = 25;
		 
	        Vector steerBoid = new Vector(0, 0);
	        int count = 0;
	        for (BoldAgent b : boids) {
	            if (!b.boldAgentData.isIncluded())
	                continue;
	
	            double distance = Vector.dist(boldAgentData.getLocation(), b.boldAgentData.getLocation());
	            if ((distance > 0) && (distance < desiredSep)) {
	                Vector difference = Vector.sub(boldAgentData.getLocation(), b.boldAgentData.getLocation());
	                difference.normalize();
	                difference.div(distance);        
	                steerBoid.add(difference);
	                count++;
	            }
	        }
	        if (count > 0) {
	            steerBoid.div(count);
	        }
	
	        if (steerBoid.mag() > 0) {
	            steerBoid.normalize();
	            steerBoid.mult(boldAgentData.getMomentum());
	            steerBoid.sub(boldAgentData.getVelocity());
	            steerBoid.limit(boldAgentData.getPower());
	            return steerBoid;
	        }
	        return new Vector(0, 0);
	    }

	Vector principle2(List<BoldAgent> boids) {
	  double desiredDist = 50;
		 
	        Vector steerBoid = new Vector(0, 0);
	        int count = 0;
	
	        for (BoldAgent b : boids) {
	            if (!b.boldAgentData.isIncluded())
	                continue;
	
	            double distance = Vector.dist(boldAgentData.getLocation(), b.boldAgentData.getLocation());
	            if ((distance > 0) && (distance < desiredDist)) {
	                steerBoid.add(b.boldAgentData.getVelocity());
	                count++;
	            }
	        }
	
	        if (count > 0) {
	            steerBoid.div(count);
	            steerBoid.normalize();
	            steerBoid.mult(boldAgentData.getMomentum());
	            steerBoid.sub(boldAgentData.getVelocity());
	            steerBoid.limit(boldAgentData.getPower());
	        }
	        return steerBoid;
	    }

	Vector principle3(List<BoldAgent> boids) {
	  double desiredDist = 50;
		 
	        Vector target = new Vector(1000, 200);
	        int count = 0;
	
	        for (BoldAgent b : boids) {
	            if (!b.boldAgentData.isIncluded())
	                continue;
	
	            double distance = Vector.dist(boldAgentData.getLocation(), b.boldAgentData.getLocation());
	            if ((distance > 0) && (distance < desiredDist)) {
	                target.add(b.boldAgentData.getLocation());
	                count++;
	            }
	        }
	        if (count > 0) {
	            target.div(count);
	            return search(target);
	        } 
	        	
	        return target;
	        
	}

	void drawBoldAgent(Graphics2D g) {
		   AffineTransform save = g.getTransform();
	   	 	g.translate(boldAgentData.getLocation().vectorData.getX(), boldAgentData.getLocation().vectorData.getY());
	        g.rotate(boldAgentData.getVelocity().heading() + PI / 2);
	        g.setColor(Color.red);
	        g.fill(boldAgent);
	        g.setColor(Color.white);
	        g.draw(boldAgent);
	        g.setTransform(save);
	
	   }

	public void startLeader(Graphics2D g, List<BoldAgent> boids, int frameWidth, int frameHeight) {  //similair method to run leader 
		leader(g, boids);
		refresh();
		drawBoldAgent(g);
	   }

}