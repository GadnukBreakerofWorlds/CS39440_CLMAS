 /*
 * @(#) ShyAgentData.java 1.0 2018/04/05
 *
 * Copyright (c) 2018 Henry Finlay.
 * All rights reserved.
 *
 */

/**
* This class is a data class for the parent class ShyAgents.java
* This class implements getters and setters for ShyAgents.java
* @author Henry Finlay
* @version 1.0 Released
* @see ShyAgents.java
* @see FlockClass.java
*/



package hef6.cmas.main;

/**
* This class is a data class for the parent class ShyAgents.java
* This class implements getters and setters for ShyAgents.java
* @author Henry Finlay
* @version 1.0 Released
* @see FlockClass.java
* @see ShyAgents.java
*/

public class ShyAgentData {
	private double power;
	private double momentum;
	private Vector location;
	private Vector velocity;
	private Vector acceleration;
	private boolean included;

	public ShyAgentData(boolean included) {
		this.included = included;
	}

	public double getPower() {
		return power;
	}

	public void setPower(double power) {
		this.power = power;
	}

	public double getMomentum() {
		return momentum;
	}

	public void setMomentum(double momentum) {
		this.momentum = momentum;
	}

	public Vector getLocation() {
		return location;
	}

	public void setLocation(Vector location) {
		this.location = location;
	}

	public Vector getVelocity() {
		return velocity;
	}

	public void setVelocity(Vector velocity) {
		this.velocity = velocity;
	}

	public Vector getAcceleration() {
		return acceleration;
	}

	public void setAcceleration(Vector acceleration) {
		this.acceleration = acceleration;
	}

	public boolean isIncluded() {
		return included;
	}

	public void setIncluded(boolean included) {
		this.included = included;
	}
}