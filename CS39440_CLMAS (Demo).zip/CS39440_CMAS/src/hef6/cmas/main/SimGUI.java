 /*
 * @(#) SimGUI.java 1.0 2018/04/05
 *
 * Copyright (c) 2018 Henry Finlay.
 * All rights reserved.
 *
 */


package hef6.cmas.main;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.util.Dictionary;
import java.util.Hashtable;

import javax.swing.JPanel;
import javax.swing.BoxLayout;
import javax.swing.JToolBar;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JSlider;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Color;
import com.jgoodies.forms.layout.FormSpecs;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionEvent;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import java.awt.Font;
import java.awt.Graphics2D;

import javax.swing.JCheckBox;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JToggleButton;

/**
* This class handles the design of the UI used by the simulator to adjust parameters of experiments. 
* SimGUI returns a JPanel which is added to the primary JFrame in Simulator.java
*
* @author Henry Finlay
* @version 1.0 Released
* @see Simulator.java
*/

public class SimGUI extends JPanel {


	private JTextField textField;
	private JTextField textField_1;
	JPanel panel_1 = new JPanel();
	JToggleButton btnRun = new JToggleButton("Run");
	JSlider sizeOfFlock = new JSlider();
	public SimGUI() {
		
		
		sizeOfFlock.setValue(20);
		sizeOfFlock.setMaximum(20);
		sizeOfFlock.setMinimum(1);
		

		
		
		

		JLabel lblNewLabel = new JLabel("Settings");
		lblNewLabel.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		
		JLabel lblFlockSize = new JLabel("Flock Size");
		lblFlockSize.setFont(new Font("Sitka Heading", Font.BOLD, 16));
		
		JLabel label = new JLabel("1");
		label.setFont(new Font("Sitka Display", Font.PLAIN, 14));
		
		JLabel label_1 = new JLabel("20");
		label_1.setFont(new Font("Sitka Display", Font.PLAIN, 14));
		
		JLabel lblTypesOfLeader = new JLabel("Types of Leader:");
		lblTypesOfLeader.setFont(new Font("Sitka Heading", Font.BOLD, 16));
		
		JLabel lblSpawnAPersistant = new JLabel("Spawn a persistant leader");
		lblSpawnAPersistant.setFont(new Font("Sitka Subheading", Font.PLAIN, 14));
		
		JCheckBox checkBox_1 = new JCheckBox("");
		
		JSlider noOfRuns = new JSlider();
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setText("" + noOfRuns.getValue());
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setText("" + sizeOfFlock.getValue());
		
		/**
		 * Handle change event for sizeOfFlock slider.
		 */
		
		    
			sizeOfFlock.addChangeListener(new ChangeListener(){
	            @Override
	            public void stateChanged(ChangeEvent e) {
	            	textField_1.setText(String.valueOf(sizeOfFlock.getValue()));
	            }
		 });
		 
			textField_1.addKeyListener(new KeyAdapter(){
	            @Override
	            public void keyReleased(KeyEvent ke) {
	                String typed = textField_1.getText();
	                sizeOfFlock.setValue(0);
	                if(!typed.matches("\\d+") || typed.length() > 3) {
	                    return;
	                }
	                int value = Integer.parseInt(typed);
	                sizeOfFlock.setValue(value);
	            }
	        });
			
			/**
			 * Handle change event for noOfRuns slider.
			 */
			
			noOfRuns.addChangeListener(new ChangeListener(){
		            @Override
		            public void stateChanged(ChangeEvent e) {
		                textField.setText(String.valueOf(noOfRuns.getValue()));
		            }
			 });
			 
			    textField.addKeyListener(new KeyAdapter(){
		            @Override
		            public void keyReleased(KeyEvent ke) {
		                String typed = textField.getText();
		                noOfRuns.setValue(0);
		                if(!typed.matches("\\d+") || typed.length() > 3) {
		                    return;
		                }
		                int value = Integer.parseInt(typed);
		                noOfRuns.setValue(value);
		            }
		        });
		    
		    
		
		JLabel label_2 = new JLabel("1");
		label_2.setFont(new Font("Sitka Display", Font.PLAIN, 14));
		
		JLabel label_3 = new JLabel("100");
		label_3.setFont(new Font("Sitka Display", Font.PLAIN, 14));
		
		
		
		JLabel lblNoOfSimulation = new JLabel("No. of runs");
		lblNoOfSimulation.setFont(new Font("Sitka Heading", Font.BOLD, 16));
		
		JList list = new JList();
		
	
		
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(83)
							.addComponent(lblNewLabel)
							.addGap(82)
							.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGroup(groupLayout.createSequentialGroup()
							.addContainerGap()
							.addComponent(label, GroupLayout.PREFERRED_SIZE, 11, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(sizeOfFlock, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(label_1, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE))
						.addGroup(groupLayout.createSequentialGroup()
							.addContainerGap()
							.addComponent(lblFlockSize)))
					.addContainerGap())
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblNoOfSimulation)
					.addContainerGap(207, Short.MAX_VALUE))
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addComponent(label_2, GroupLayout.PREFERRED_SIZE, 11, GroupLayout.PREFERRED_SIZE)
					.addGap(2)
					.addComponent(noOfRuns, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(label_3, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
					.addComponent(textField, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE)
					.addGap(6))
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblTypesOfLeader)
					.addContainerGap(170, Short.MAX_VALUE))
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(168)
					.addComponent(list, GroupLayout.PREFERRED_SIZE, 1, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(129, Short.MAX_VALUE))
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(100)
					.addComponent(btnRun, GroupLayout.PREFERRED_SIZE, 85, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(113, Short.MAX_VALUE))
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(214)
							.addComponent(checkBox_1, GroupLayout.PREFERRED_SIZE, 21, GroupLayout.PREFERRED_SIZE))
						.addComponent(lblSpawnAPersistant, GroupLayout.PREFERRED_SIZE, 178, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(53, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(5)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(5)
							.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGroup(groupLayout.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(lblNewLabel)))
					.addPreferredGap(ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
					.addComponent(lblFlockSize)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addComponent(label, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE)
						.addComponent(sizeOfFlock, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
							.addComponent(label_1, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE)
							.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
					.addGap(28)
					.addComponent(lblTypesOfLeader)
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblSpawnAPersistant, GroupLayout.PREFERRED_SIZE, 19, GroupLayout.PREFERRED_SIZE)
						.addComponent(checkBox_1, GroupLayout.PREFERRED_SIZE, 21, GroupLayout.PREFERRED_SIZE))
					.addGap(48)
					.addComponent(lblNoOfSimulation, GroupLayout.PREFERRED_SIZE, 21, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addComponent(noOfRuns, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_2, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE)
						.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
							.addComponent(label_3, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE)
							.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
					.addGap(40)
					.addComponent(list, GroupLayout.PREFERRED_SIZE, 1, GroupLayout.PREFERRED_SIZE)
					.addGap(28)
					.addComponent(btnRun, GroupLayout.PREFERRED_SIZE, 47, GroupLayout.PREFERRED_SIZE)
					.addGap(150))
		);
	
			
		
		
		
		setLayout(groupLayout);
		
		
			
			
			
		}
	public JToggleButton setButton1() {
	    return this.btnRun;
	    
	}
	 public void runBtnAddActionListener(ActionListener al) {
		    btnRun.addActionListener(al);
		  }
	 public JPanel getPanel() {
		    return panel_1;
		  }
	 public int getFlockSize() {
		 int flockSize = sizeOfFlock.getValue();
		return flockSize;
		 
	 }
	}
	
	
	

