 /*
 * @(#) SimulatorTest.java 1.0 2018/04/05
 *
 * Copyright (c) 2018 Henry Finlay.
 * All rights reserved.
 *
 */


package hef6.cmas.main;

import static org.junit.Assert.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;

import org.junit.jupiter.api.Test;

/**
* This class implements JUnit tests for Simulator.java
* 
* @author Henry Finlay
* @version 1.0 Released
* @see Simulator.java
*/

class SimulatorTest {


	/**
	 * Test method for {@link hef6.cmas.main.Simulator#spawnAgents()}.
	 */
	@Test
	void testSpawnAgents() {
		
		double frameWidth = 1200;
		double frameHeight = 600;
		int flockBoids = 20;
		int leaderBoids = 1;
		Flock shyAgents;
		Leader boldAgents;
		boldAgents = Leader.generate(frameWidth, frameHeight, leaderBoids);
		shyAgents = Flock.generate(frameWidth, frameHeight, flockBoids);
		
		assertNotNull(shyAgents);
		assertNotNull(boldAgents);
		assertNotEquals(boldAgents, shyAgents);
	}


}
