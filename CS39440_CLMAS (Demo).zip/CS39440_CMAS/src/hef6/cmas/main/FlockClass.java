 /*
 * @(#) FlockClass.java 1.0 2018/04/05
 *
 * Copyright (c) 2018 Henry Finlay.
 * All rights reserved.
 *
 */

/**
* This class implements the flock 
* <p>
* Methods within this class generates the flock as well as tracking the flock
* as it moves through the simulated environment and establishing whether members 
* of the flock have located the food source
* 
* @author Henry Finlay
* @version 1.0 Released
* @see ShyAgents.java
* @see Simulator.java
* @see FlockData.java
*/

package hef6.cmas.main;

import java.awt.Graphics2D;

/**
* This class generates the flock of shy agents and provides a method to run this agent type
* <p>
* This class also tracks the location of the flock within the simulation environment
* and determined whether or not members of the flock have reached the food source
* @author Henry Finlay
* @version 1.0 Released
* @see ShyAgents.java
* @see Simulator.java
* @see BoldAgents.java
*/

public class FlockClass {

	protected FlockData flockData = new FlockData();

	protected static Flock generate(double frameWidth, double frameHeight, int numBoids) {
	    Flock flock = new Flock();
	    for (int i = 0; i < numBoids; i++)
	        flock.addBoid(new ShyAgent(frameWidth, frameHeight));
	    return flock;
	}

	protected void run(Graphics2D g, int frameWidth, int frameHeight) {
	    for (ShyAgent b : flockData.getShyBoids()) {
	        b.startFlock(g, flockData.getShyBoids(), frameWidth, frameHeight, flockData.getBoldBoids());
	    }
	    
	}

	protected boolean leftEnvironment(int frameWidth) {
	    int count = 0;
	    for (ShyAgent b : flockData.getShyBoids()) {
	        if (b.shyAgentData.getLocation().vectorData.getX() + ShyAgent.shyAgentSize > frameWidth) //will also be used to calculate votes based on whether boids is near food
	            count++;
	    }
	    return flockData.getShyBoids().size() == count;
	}

	void addBoid(ShyAgent b) {
	    flockData.getShyBoids().add(b);
	}

	public FlockClass() {
		super();
	}

	protected int flockFoundFood() {
		int noSuccessful = 0;
		for (ShyAgent b : flockData.getShyBoids()) {
			if (b.shyAgentData.getLocation().vectorData.getX() + ShyAgent.shyAgentSize >= 1000 && b.shyAgentData.getLocation().vectorData.getY() + ShyAgent.shyAgentSize >= 200 && b.shyAgentData.getLocation().vectorData.getY() + ShyAgent.shyAgentSize < 400) {
				noSuccessful++;
			 }
		}
		return noSuccessful;
	}

}