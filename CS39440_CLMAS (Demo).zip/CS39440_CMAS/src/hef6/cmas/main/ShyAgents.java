 /*
 * @(#) ShyAgents.java 1.0 2018/04/05
 *
 * Copyright (c) 2018 Henry Finlay.
 * All rights reserved.
 *
 */


package hef6.cmas.main;

import static java.lang.Math.PI;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Path2D;
import java.util.List;
import java.util.Random;

/**
* This class implements Shy Agents 
* <p>
* This class implements the 3 principles of the Boids algorithm, Separation, Alignment and Cohesion 
* with these principles corresponding the following methods: 
* principle1(List<ShyAgent> boids)
* principle2(List<ShyAgent> boids)
* principle3(List<ShyAgent> boids)
* This class paints ShyAgents 
* This class implements attributes/behaviours of ShyAgents
* 
* @author Henry Finlay
* @version 1.0 Released
* @see ShyAgentsData.java
* @see FlockClass.java
* @see Simulator.java
*/

public class ShyAgents {

	protected static final Random r = new Random();
	static final Vector shift = new Vector(0.02, 0);
	protected static final int shyAgentSize = 3;
	protected static final Path2D shyAgent = new Path2D.Double();
	protected ShyAgentData shyAgentData = new ShyAgentData(true);

	public ShyAgents() {
		super();
	}

	void refresh() {
		  shyAgentData.getVelocity().add(shyAgentData.getAcceleration());
		  shyAgentData.getVelocity().limit(shyAgentData.getMomentum());
		  shyAgentData.getLocation().add(shyAgentData.getVelocity());
		  shyAgentData.getAcceleration().mult(0);
	}

	void addPower(Vector power) {
	    shyAgentData.getAcceleration().add(power);
	}

	Vector search(Vector targetBoid) {
	    Vector steerBoid = Vector.sub(targetBoid, shyAgentData.getLocation());
	    steerBoid.normalize();
	    steerBoid.mult(shyAgentData.getMomentum());
	    steerBoid.sub(shyAgentData.getVelocity());
	    steerBoid.limit(shyAgentData.getPower());
	    return steerBoid;
	}

	void flock(Graphics2D g, List<ShyAgent> boids, List<BoldAgent> boids1) {
	    vision(g, boids, boids1);
	
	    Vector separation = principle1(boids, boids1);
	    Vector alignment = principle2(boids, boids1);
	    Vector cohesion = principle3(boids, boids1);
	
	    separation.mult(2.5);
	    alignment.mult(1.5);
	    cohesion.mult(1.3);
	    
	    addPower(separation);
	    addPower(alignment);
	    addPower(cohesion);
	    addPower(shift);
	    
	    
	}

	void vision(Graphics2D g, List<ShyAgent> boids, List<BoldAgent> boids1) {
	    double visionDistance = 100;
	    double fieldOfView = PI * 0.85;
	
	    for (ShyAgent b : boids) {
	        b.shyAgentData.setIncluded(false);
	
	        if (b == this)
	            continue;
	
	        double distance = Vector.dist(shyAgentData.getLocation(), b.shyAgentData.getLocation());
	        if (distance <= 0 || distance > visionDistance)
	            continue;
	
	        Vector lineOfSight = Vector.sub(b.shyAgentData.getLocation(), shyAgentData.getLocation());
	
	        double angle = Vector.angleBetween(lineOfSight, shyAgentData.getVelocity());
	        if (angle < fieldOfView)
	            b.shyAgentData.setIncluded(true);
	    }
	    
	    for (BoldAgents b : boids1) {
	        b.boldAgentData.setIncluded(false);
	
	        if (b == boids1)
	            continue;
	
	        double distance = Vector.dist(shyAgentData.getLocation(), b.boldAgentData.getLocation());
	        if (distance <= 0 || distance > visionDistance)
	            continue;
	
	        Vector lineOfSight = Vector.sub(b.boldAgentData.getLocation(), shyAgentData.getLocation());
	
	        double angle = Vector.angleBetween(lineOfSight, shyAgentData.getVelocity());
	        if (angle < fieldOfView)
	            b.boldAgentData.setIncluded(true);
	    }
	}

	Vector principle1(List<ShyAgent> boids, List<BoldAgent> boids1) {
	   double desiredSep = 25;
		 
	    Vector steerBoid = new Vector(0, 0);
	    int count = 0;
	    for (ShyAgent b : boids) {
	        if (!b.shyAgentData.isIncluded())
	            continue;
	
	        double distance = Vector.dist(shyAgentData.getLocation(), b.shyAgentData.getLocation());
	        if ((distance > 0) && (distance < desiredSep)) {
	            Vector difference = Vector.sub(shyAgentData.getLocation(), b.shyAgentData.getLocation());
	            difference.normalize();
	            difference.div(distance);      
	            steerBoid.add(difference);
	            count++;
	        }
	    }
	    
	    for (BoldAgents b : boids1) {
	        if (!b.boldAgentData.isIncluded())
	            continue;
	
	        double distance = Vector.dist(shyAgentData.getLocation(), b.boldAgentData.getLocation());
	        if ((distance > 0) && (distance < desiredSep)) {
	            Vector difference = Vector.sub(shyAgentData.getLocation(), b.boldAgentData.getLocation());
	            difference.normalize();
	            difference.div(distance);       
	            steerBoid.add(difference);
	            count++;
	        }
	    }
	    if (count > 0) {
	        steerBoid.div(count);
	    }
	
	    if (steerBoid.mag() > 0) {
	        steerBoid.normalize();
	        steerBoid.mult(shyAgentData.getMomentum());
	        steerBoid.sub(shyAgentData.getVelocity());
	        steerBoid.limit(shyAgentData.getPower());
	        return steerBoid;
	    }
	    return new Vector(0, 0);
	}

	Vector principle2(List<ShyAgent> boids, List<BoldAgent> boids1) {
	  double desiredDist = 50;
		 
	    Vector steerBoid = new Vector(0, 0);
	    int count = 0;
	
	    for (ShyAgent b : boids) {
	        if (!b.shyAgentData.isIncluded())
	            continue;
	
	        double distance = Vector.dist(shyAgentData.getLocation(), b.shyAgentData.getLocation());
	        if ((distance > 0) && (distance < desiredDist)) {
	            steerBoid.add(b.shyAgentData.getVelocity());
	            count++;
	        }
	    }
	    
	    for (BoldAgents b : boids1) {
	        if (!b.boldAgentData.isIncluded())
	            continue;
	
	        double distance = Vector.dist(shyAgentData.getLocation(), b.boldAgentData.getLocation());
	        if ((distance > 0) && (distance < desiredDist)) {
	            steerBoid.add(b.boldAgentData.getVelocity());
	            count++;
	        }
	    }
	
	    if (count > 0) {
	        steerBoid.div(count);
	        steerBoid.normalize();
	        steerBoid.mult(shyAgentData.getMomentum());
	        steerBoid.sub(shyAgentData.getVelocity());
	        steerBoid.limit(shyAgentData.getPower());
	    }
	    return steerBoid;
	}

	Vector principle3(List<ShyAgent> boids, List<BoldAgent> boids1) {
	  double desiredDist = 50;
		 
	    Vector targetBoid = new Vector(0, 0);
	    int count = 0;
	
	    for (ShyAgent b : boids) {
	        if (!b.shyAgentData.isIncluded())
	            continue;
	
	        double distance = Vector.dist(shyAgentData.getLocation(), b.shyAgentData.getLocation());
	        if ((distance > 0) && (distance < desiredDist)) {
	            targetBoid.add(b.shyAgentData.getLocation());
	            count++;
	        }
	    }
	    
	    for (BoldAgents b : boids1) {
	        if (!b.boldAgentData.isIncluded())
	            continue;
	
	        double distance = Vector.dist(shyAgentData.getLocation(), b.boldAgentData.getLocation());
	        if ((distance > 0) && (distance < desiredDist)) {
	            targetBoid.add(b.boldAgentData.getLocation());
	            count++;
	        }
	    }
	    if (count > 0) {
	        targetBoid.div(count);
	        return search(targetBoid);
	    }
	    return targetBoid;
	}

	void drawShyAgents(Graphics2D g) {
		 AffineTransform save = g.getTransform();
		 g.translate(shyAgentData.getLocation().vectorData.getX(), shyAgentData.getLocation().vectorData.getY());
	     g.rotate(shyAgentData.getVelocity().heading() + PI / 2);
	     g.setColor(Color.green);
	     g.fill(shyAgent);
	     g.setColor(Color.green);
	     g.draw(shyAgent);
	     g.setTransform(save);  
	}

	public void startFlock(Graphics2D g, List<ShyAgent> boids, int frameWidth, int frameHeight, List<BoldAgent> boids1) {  
	flock(g, boids, boids1);
	refresh();
	drawShyAgents(g);
	
	}

}