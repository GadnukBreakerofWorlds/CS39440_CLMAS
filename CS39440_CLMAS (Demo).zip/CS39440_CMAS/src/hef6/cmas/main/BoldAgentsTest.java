 /*
 * @(#) BoldAgentsTest.java 1.0 2018/04/05
 *
 * Copyright (c) 2018 Henry Finlay.
 * All rights reserved.
 *
 */


package hef6.cmas.main;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Random;

import org.junit.jupiter.api.Test;

/**
* This class implements JUnit tests for BoldAgents.java
* 
* @author Henry Finlay
* @version 1.0 Released
* @see BoldAgents.java
*/

class BoldAgentsTest {



	@Test
	void testRefresh() {
		
	
		boolean included = true;
		 Random r = new Random();
		 double x = 100;
		 double y = 100;
		 VectorData vectorData = new VectorData();
		 BoldAgentData boldAgentData = new BoldAgentData(included);
		 Vector testVelocity1 = new Vector(x,y);
		 Vector testVelocity2 = new Vector();
		 Vector testAcceleration = new Vector(x, y);
		 Vector nullAcceleration = new Vector();
		 testVelocity1.add(testAcceleration);
		 testVelocity2.add(nullAcceleration);
		 vectorData.setX(x);
		
	 assertNotEquals(testVelocity1, testVelocity2);
	   
	}
	
}

	