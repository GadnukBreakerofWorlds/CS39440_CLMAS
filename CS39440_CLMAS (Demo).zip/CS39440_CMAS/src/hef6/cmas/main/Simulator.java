 /*
 * @(#) Simulator.java 1.0 2018/04/05
 *
 * Copyright (c) 2018 Henry Finlay.
 * All rights reserved.
 *
 */


package hef6.cmas.main;

import static java.lang.Math.acos;
import static java.lang.Math.atan2;
import static java.lang.Math.pow;
import static java.lang.Math.sqrt;

/**
 * Main.java - Main class for the proposed MAS
 * <p>
 * Used to call initialisation method to start a simulation within the environment
 * 
 * @author hef6
 * @version 0.3  DRAFT
 * @see N/A
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

/**
* Simulator handles the primary functions of simulating the environment e.g. spawning agents.
* This class sets the size of the environment.
* This class also created the frame and add the SimGUI panel to this frame.
* This class handles graphical aspects of the simulator such as drawing the food source and defining the shapes of agents.
* Simulator also houses the Vector class which implements mathematical operations used to manipulate the values vectors in other classes
* 
*
* @author Henry Finlay
* @version 1.0 Released
* @see FlockClass.java
* @see LeaderClass.java
* @see SimGUI.java
*/

public class Simulator extends JPanel {
	   
    Flock shyAgents;
    Leader boldAgent;
    final int frameWidth, frameHeight;
    private static SimGUI panelWithRunBtn = new SimGUI();
    int countRuns = 0;
    Rectangle foodSource = new Rectangle(1000,200,200,150);
    public Simulator() {
        frameWidth = 1200;
        frameHeight = 600;
      
        setPreferredSize(new Dimension(frameWidth, frameHeight));
        setBackground(Color.black);

        spawnAgents();
        
        new Timer(17, (ActionEvent e) -> {
            if (shyAgents.leftEnvironment(frameWidth))
            	spawnAgents();
            repaint();
        }).start(); 
    
        new Timer(0, (ActionEvent e1) -> {
            if (shyAgents.flockFoundFood() > 0) {
            	animateFood((Graphics2D) getGraphics());
            } else {
            	animateNoFood((Graphics2D) getGraphics());
            }
        }).start(); 
        
        new Timer(17, (ActionEvent e2) -> {
            if (shyAgents.leftEnvironment(frameWidth) != true) {
            	shyAgents.flockFoundFood();
            } else if (shyAgents.leftEnvironment(frameWidth) == true) {
            	countRuns++; 
            	System.out.println("Run No: " + countRuns + " No Succ: " + (shyAgents.flockFoundFood() + boldAgent.leaderFoundFood()));
            }
        }).start(); 
        
        
        panelWithRunBtn.runBtnAddActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent arg0) {
            	shyAgents.run((Graphics2D) getGraphics(), frameWidth, frameHeight);
        	}
        });
                
    }
        

    private static void createFrameAndGUI() {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(panelWithRunBtn, BorderLayout.EAST);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Simulator v1.0");
        frame.setResizable(false);
        frame.add(new Simulator(), BorderLayout.CENTER);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
      }


    
    void animateNoFood(Graphics2D g) {
    	g.draw(foodSource);
     	g.setColor(Color.green);
     	g.fill(foodSource);
     }
    
    void animateFood(Graphics2D g) {
    	g.draw(foodSource);
    	g.setColor(Color.red);
    	g.fill(foodSource);
    }
 
    public void spawnAgents() {
    	
    	Random r = new Random();
    	int yRandom = r.nextInt(400);
    	int xRandom = r.nextInt(100);
    	SimGUI getFlock = new SimGUI();
        shyAgents = Flock.generate(xRandom, yRandom, getFlock.getFlockSize());
        boldAgent = Leader.generate(xRandom, 100, 1);

    	}

    public void paintComponent(Graphics gg) {
        super.paintComponent(gg);
        Graphics2D g = (Graphics2D) gg;
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
        		RenderingHints.VALUE_ANTIALIAS_ON);
   
        shyAgents.run(g, frameWidth, frameHeight);
      //  boldAgent.run(g, frameWidth, frameHeight);

		}; 
      
 
    
    public static void main(String[] args) {
    	
    	SwingUtilities.invokeLater(new Runnable() {
    		public void run() {
    		    	  createFrameAndGUI();
    		}
    	});
    }
    
	}

class ShyAgent extends ShyAgents {

	static {
    	shyAgent.moveTo(0, -shyAgentSize * 2);
    	shyAgent.lineTo(-shyAgentSize, shyAgentSize * 2);
    	shyAgent.lineTo(shyAgentSize, shyAgentSize * 2);
    	shyAgent.closePath();
    }
 
    ShyAgent(double x, double y) {
        shyAgentData.setAcceleration(new Vector());
        shyAgentData.setVelocity(new Vector(r.nextInt(3) + 1, r.nextInt(3) - 1));
        shyAgentData.setLocation(new Vector(x, y));
        shyAgentData.setMomentum(3.0);
        shyAgentData.setPower(0.05);
    }
    
}

class BoldAgent extends BoldAgents {
	
	static {
	   boldAgent.moveTo(0, -boldAgentSize * 2);
	   boldAgent.lineTo(-boldAgentSize, boldAgentSize * 2);
	   boldAgent.lineTo(boldAgentSize, boldAgentSize * 2);
	   boldAgent.closePath();
   }

   BoldAgent(double x, double y) {
       boldAgentData.setAcceleration(new Vector());
       boldAgentData.setVelocity(new Vector(r.nextInt(3) + 1, r.nextInt(3) - 1));
       boldAgentData.setLocation(new Vector(x, y));
       boldAgentData.setMomentum(3.0);
       boldAgentData.setPower(0.05);
   }
   

}



class Flock extends FlockClass {
    Flock() {
        flockData.setShyBoids(new ArrayList<>());
        flockData.setBoldBoids(new ArrayList<>());
    }
    
}


class Leader extends LeaderClass {
    Leader() {
        leaderData.setBoldBoids(new ArrayList<>());
    }
    
 

 

}
class Vector {
    VectorData vectorData = new VectorData();

	Vector() {
    }
 
    Vector(double x, double y) {
        this.vectorData.setX(x);
        this.vectorData.setY(y);
    }
 
    void add(Vector v) {
        vectorData.setX(vectorData.getX() + v.vectorData.getX());
        vectorData.setY(vectorData.getY() + v.vectorData.getY());
    }
 
    void sub(Vector v) {
        vectorData.setX(vectorData.getX() - v.vectorData.getX());
        vectorData.setY(vectorData.getY() - v.vectorData.getY());
    }
 
    void div(double val) {
        vectorData.setX(vectorData.getX() / val);
        vectorData.setY(vectorData.getY() / val);
    }
 
    void mult(double val) {
        vectorData.setX(vectorData.getX() * val);
        vectorData.setY(vectorData.getY() * val);
    }
 
    double mag() {
        return sqrt(pow(vectorData.getX(), 2) + pow(vectorData.getY(), 2));
    }
 
    double dot(Vector v) {
        return vectorData.getX() * v.vectorData.getX() + vectorData.getY() * v.vectorData.getY();
    }
 
    void normalize() {
        double mag = mag();
        if (mag != 0) {
            vectorData.setX(vectorData.getX() / mag);
            vectorData.setY(vectorData.getY() / mag);
        }
    }
 
    void limit(double lim) {
        double mag = mag();
        if (mag != 0 && mag > lim) {
            vectorData.setX(vectorData.getX() * (lim / mag));
            vectorData.setY(vectorData.getY() * (lim / mag));
        }
    }
 
    double heading() {
        return atan2(vectorData.getY(), vectorData.getX());
    }
 
    static Vector sub(Vector v, Vector v2) {
        return new Vector(v.vectorData.getX() - v2.vectorData.getX(), v.vectorData.getY() - v2.vectorData.getY());
    }
 
    static double dist(Vector v, Vector v2) {
        return sqrt(pow(v.vectorData.getX() - v2.vectorData.getX(), 2) + pow(v.vectorData.getY() - v2.vectorData.getY(), 2));
    }
 
    static double angleBetween(Vector v, Vector v2) {
        return acos(v.dot(v2) / (v.mag() * v2.mag()));
    }
    
}