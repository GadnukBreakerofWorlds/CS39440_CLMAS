 /*
 * @(#) LeaderClass.java 1.0 2018/04/05
 *
 * Copyright (c) 2018 Henry Finlay.
 * All rights reserved.
 *
 */

/**
* This class implements leaders
* <p>
* Methods within this class generates leaders as well as tracking bold-agents as they
* move through the simulated environment and establishing if these agents have 
* reached the food source
* 
* @author Henry Finlay
* @version 1.0 Released
* @see BoldAgents.java
* @see Simulator.java
* @see LeaderData.java
*/


package hef6.cmas.main;

import java.awt.Graphics2D;

/**
* This class generates the bold agents and provides a method to run this agent type
* <p>
* This class also tracks the location of the flock within the simulation environment
* and determined whether or not any bold agents have reached the food source
* @author Henry Finlay
* @version 1.0 Released
* @see ShyAgents.java
* @see Simulator.java
* @see BoldAgents.java
*/

public class LeaderClass {

	protected LeaderData leaderData = new LeaderData();

	protected static Leader generate(double frameWidth, double frameHeight, int numBoids) {
	    Leader leader = new Leader();
	    for (int i = 0; i < numBoids; i++)
	        leader.addBoid(new BoldAgent(frameWidth, frameHeight));
	    return leader;
	}

	protected void run(Graphics2D g, int frameWidth, int frameHeight) {
	    for (BoldAgent b : leaderData.getBoldBoids()) {
	        b.startLeader(g, leaderData.getBoldBoids(), frameWidth, frameHeight);
	        
	    }
	}

	void addBoid(BoldAgent b) {
	    leaderData.getBoldBoids().add(b);
	}

	public LeaderClass() {
		super();
	}

	protected int leaderFoundFood() {
		int noSuccessful = 0;
		for (BoldAgent b : leaderData.getBoldBoids()) {
			if (b.boldAgentData.getLocation().vectorData.getX() + ShyAgent.shyAgentSize >= 1000 && b.boldAgentData.getLocation().vectorData.getY() + ShyAgent.shyAgentSize >= 200 && b.boldAgentData.getLocation().vectorData.getY() + ShyAgent.shyAgentSize < 400) {
				 noSuccessful++;
			 }
		}
		return noSuccessful;
	}

}